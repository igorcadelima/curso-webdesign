<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Cadastro de alunos MC - Adicionar aluno</title>
</head>
<body>
	<h1>Sistema de alunos MC</h1>

	<!-- Incluir menu.php -->

	<h3>Cadastro de aluno</h3>

	<!-- Informar script que manipulará os dados do form e o método de envio -->
	<!-- Para cada campo de entrada, atribuir um nome -->
	<form action="" method="">
		<p>
			<label>Nome:</label>
			<input type="text" name="">
		</p>
		<p>
			<label>Login:</label>
			<input type="text" name="">
		</p>
		<p>
			<label>Senha:</label>
			<input type="text" name="">
		</p>
		<p>
			<input type="submit" value="Salvar">
		</p>
	</form>

</body>
</html>