<?php 
	
	// incluir conexao.php

	// Pegar os dados submetidos e salva-os em variáveis

	// Criar comando SQL que atualiza o aluno em questão

	// Realizar transação ou matar execução com mensagem de erro

	// Retornar para listagem de alunos

 ?>