<?php 

  $servidor = "";  // Endereço do servidor
  $usuario = "";        // Nome do usuário de acesso ao servidor
  $senha = "";              // Senha do usuário de acesso ao servidor
  $banco = "";     // Nome do banco de dados que será manipulado

  // Executar conexão com o servidor ou mata execução

  // Selecionar banco de dados ou mata execução

 ?>