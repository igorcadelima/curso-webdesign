<?php 

	// incluir conexao.php

	// Pegar id do aluno a ser excluído

	// Criar comando SQL que remove aluno da tabela cujo campo id = $id

	// Realizar transação ou matar execução com mensagem de erro

	// Retornar para listagem de alunos

 ?>