<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Cadastro de alunos MC - Home</title>
</head>
<body>
	<h1>Sistema de alunos MC</h1>

	<!-- Incluir menu.php -->

</body>
</html>