<p>
	<a href="index.php">Home</a> |
	<a href="lista-alunos.php">Lista de alunos</a> | 
	<a href="adicionar-aluno.php">Adicionar aluno</a>
</p>