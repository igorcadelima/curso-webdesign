<?php 
	
	// incluir conexao.php

	// Pegar os dados submetidos e salva-os em variáveis

	// Criar comando SQL que insere novo aluno na tabela usuario, 
	// nas devidas colunas, os valores $nome, $login, e $senha

	// Realizar transação ou matar execução com mensagem de erro

	// Retornar para listagem de alunos

 ?>