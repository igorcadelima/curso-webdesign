<?php 
	
	// incluir conexao.php

	// Pegar os dados submetidos e salva-os em variáveis

	// Criar comando SQL que atualiza o filme em questão

	// Realizar transação

	// Retornar para listagem de filmes

 ?>