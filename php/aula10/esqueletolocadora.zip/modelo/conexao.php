<?php 
  
  /* 
   * Esse script servirá de base para todas as páginas que tiverem que
   * realizar alguma comunicação com o banco de dados.
   */

  $servidor = "";  // Endereço do servidor
  $usuario = "";        // Nome do usuário de acesso ao servidor
  $senha = "";              // Senha do usuário de acesso ao servidor
  $banco = "";     // Nome do banco de dados que será manipulado

  // Executar conexão com o servidor

  // Selecionar banco de dados

 ?>