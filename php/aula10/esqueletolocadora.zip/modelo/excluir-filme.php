<?php 

	/* Criar script para excluir filme */

	// incluir conexao.php

	// Pegar id do filme a ser excluído

	// Criar comando SQL que remove filme da tabela

	// Realizar transação

	// Retornar para listagem de filmes

 ?>