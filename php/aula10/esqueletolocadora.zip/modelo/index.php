<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Locadora do Pedrinho - Home</title>
</head>
<body>
	<h1>Locadora do Pedrinho</h1>

	<?php include 'menu.php'; ?>

</body>
</html>