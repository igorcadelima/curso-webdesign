<p>
	<a href="index.php">Home</a> |
	<a href="lista-filmes.php">Lista de filmes</a> | 
	<a href="adicionar-filme.php">Adicionar filme</a>
</p>