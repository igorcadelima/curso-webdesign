<?php 
	
	// incluir conexao.php

	// Pegar os dados submetidos e salva-os em variáveis

	// Criar comando SQL que insere na tabela de filmes, nas devidas colunas, os valores $titulo,
	// $valorLocacao, e $sinopse

	// Realizar transação

	// Retornar para listagem de filmes

 ?>